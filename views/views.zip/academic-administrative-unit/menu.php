<?php

use yii\helpers\Html; ?>
<p>
<?= Html::a('Create/Add Unit', ['create'], ['class' => 'btn btn-success']) ?>
</p>