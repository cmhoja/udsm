<div class="site-error" style="width: 90%;margin: 3%;margin-top: 7%;">

    <h3>Error (#404)</h3>

    <div class="alert alert-danger">
        Page not found.    </div>
    <p style="margin-left: 0.5%;font-size: 1em">
        Please contact us if you think this is a server error. Thank you.
    </p>

</div>