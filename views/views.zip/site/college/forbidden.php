<?php
use kartik\growl\Growl;
use yii\helpers\Html;
use yii\jui\Dialog;

?>
<div class="alert alert-danger" role="danger">
    You are not allowed to perform this action ! Contact your System Administrator if you this this is server error
</div>

