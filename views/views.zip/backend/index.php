<?php

use miloschuman\highcharts\Highcharts;

/* @var $this yii\web\View */
?>
<div class="site-index">

    <div class="jumbotron">
        <!--<h1>Welcome to UDSM Content Management System</h1>-->
    </div>

    <div class="body-content" style="background: red;">
        <?php
        echo $this->title;
        ?>
    </div>
</div>
