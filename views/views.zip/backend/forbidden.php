<?php
//die('Hukuuuu');
use kartik\growl\Growl;
use yii\helpers\Html;
use yii\jui\Dialog;

/* @var $this yii\web\View */
$this->title = 'The National Database for Climate and Hydrology (NDCH)';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="alert alert-danger" role="danger">
    You are not allowed to perform this action ! Contact your <strong>(NDCH) </strong> System Administrator
</div>

